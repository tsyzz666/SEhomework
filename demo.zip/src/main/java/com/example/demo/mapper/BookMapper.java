package com.example.demo.mapper;

import com.example.demo.entity.Book;
import org.apache.ibatis.annotations.*;

import java.util.ArrayList;

@Mapper
public interface BookMapper {

    ArrayList<Book> select(Book book);
    Integer insert(Book book);
    Integer update(Book book);
    Integer deleteById(String bookID);
    ArrayList<Book> recommendById(String cusID);
    ArrayList<Book> recommendByID_new();
}
